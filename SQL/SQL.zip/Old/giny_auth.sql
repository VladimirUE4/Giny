/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50724
 Source Host           : localhost:3306
 Source Schema         : giny_auth

 Target Server Type    : MySQL
 Target Server Version : 50724
 File Encoding         : 65001

 Date: 23/04/2021 22:05:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `LastSelectedServerId` int(11) NULL DEFAULT 0,
  `IPs` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `CharactersSlots` int(255) NULL DEFAULT 5,
  `Banned` int(255) NULL DEFAULT 0,
  `Role` int(255) NULL DEFAULT 1,
  `Nickname` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Ogrines` int(11) NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 11 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of accounts
-- ----------------------------
INSERT INTO `accounts` VALUES (1, 'admin', 'aa', 1, '127.0.0.1', 15, 0, 5, 'Street', 0);
INSERT INTO `accounts` VALUES (2, 'test', 'aa', 1, '127.0.0.1', 15, 0, 5, 'LeNickname', 0);
INSERT INTO `accounts` VALUES (3, 'test2', 'aa', 1, '127.0.0.1', 15, 0, 5, 'zaeaze', 0);
INSERT INTO `accounts` VALUES (4, 'oo', 'aa', 1, '127.0.0.1', 15, 0, 5, 'Princesse', 0);
INSERT INTO `accounts` VALUES (7, 'lovely', 'aa', 0, '127.0.0.1', 5, 0, 1, 'sdsqd', 0);
INSERT INTO `accounts` VALUES (8, 'Flow', 'aa', 0, NULL, 5, 0, 1, NULL, 0);
INSERT INTO `accounts` VALUES (9, 'Bruce123', 'aa', 0, NULL, 5, 0, 1, NULL, 0);
INSERT INTO `accounts` VALUES (10, 'Bruce345', 'aa', 0, NULL, 5, 0, 1, NULL, 0);

-- ----------------------------
-- Table structure for webcomments
-- ----------------------------
DROP TABLE IF EXISTS `webcomments`;
CREATE TABLE `webcomments`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `NewId` int(11) NULL DEFAULT NULL,
  `Author` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Content` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `Date` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 28 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of webcomments
-- ----------------------------
INSERT INTO `webcomments` VALUES (20, 1, 'admin', 'ezezrzreer', '2021-04-07 21:04:10');
INSERT INTO `webcomments` VALUES (21, 1, 'admin', 'zazaeazeazea\'', '2021-04-07 21:11:29');
INSERT INTO `webcomments` VALUES (22, 1, 'admin', 'Je suce mon gros cul\'\'\'\'\'\'', '2021-04-07 21:11:35');
INSERT INTO `webcomments` VALUES (23, 5, 'admin', 'J\'ai trop hate !!!!', '2021-04-08 02:27:59');
INSERT INTO `webcomments` VALUES (24, 5, 'admin', 'Mouais, bof', '2021-04-08 02:33:18');
INSERT INTO `webcomments` VALUES (25, 5, 'admin', 'Ok cool :D', '2021-04-08 02:33:27');
INSERT INTO `webcomments` VALUES (26, 5, 'Bruce345', 'Pourquoi on ne peut pas obtenir la rate xp plusieurs fois ???', '2021-04-08 02:36:58');

-- ----------------------------
-- Table structure for webnews
-- ----------------------------
DROP TABLE IF EXISTS `webnews`;
CREATE TABLE `webnews`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Content` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `Views` int(11) NULL DEFAULT NULL,
  `ImageLink` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `AuthorName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Date` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 56 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of webnews
-- ----------------------------
INSERT INTO `webnews` VALUES (5, 'Pandala 3 disponible en jeu ! ', '         <p>Bonjour à tous, <br> Après des mois de travail <strong>acharné</strong> \r\nnous avons le plaisir de vous annoncer l\'ouverture de Sufokia !  </p>\r\n\r\nCependant, vous noterez que le serveur de jeu et le site web sont actuellement en <b>BETA test</b>. \r\nAinsi, nous solicitons votre aide pour partir a la chasse aux <b>bugs</b> !  \r\n\r\nCaca     ', 160, 'assets/images/news/15.jpg', 'Admin', '2021-04-07 18:47:29');
INSERT INTO `webnews` VALUES (2, 'Une bonne année 2021 !', ' hello ', 4, 'assets/images/news/12.jpg', 'Admin', '2021-04-16 00:05:18');
INSERT INTO `webnews` VALUES (3, 'Pokéfus, en avant !', ' <b> Pokéfus est de retour ! </b> ', 7, 'assets/images/news/11.jpg', 'Admin', '2021-05-01 00:05:37');
INSERT INTO `webnews` VALUES (4, 'L\'aventure commence !', '     super     ', 12, 'assets/images/news/8.jpg', 'Admin', '2021-05-02 00:05:55');
INSERT INTO `webnews` VALUES (1, 'Correction de bugs', '  Génial  ', 6, 'assets/images/news/13.jpg', 'Admin', '2021-04-16 00:06:20');

-- ----------------------------
-- Table structure for worldcharacters
-- ----------------------------
DROP TABLE IF EXISTS `worldcharacters`;
CREATE TABLE `worldcharacters`  (
  `Id` int(11) NOT NULL,
  `CharacterId` bigint(20) NULL DEFAULT NULL,
  `AccountId` int(11) NULL DEFAULT NULL,
  `ServerId` smallint(6) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of worldcharacters
-- ----------------------------
INSERT INTO `worldcharacters` VALUES (15, 1, 1, 1);
INSERT INTO `worldcharacters` VALUES (20, 6, 1, 1);
INSERT INTO `worldcharacters` VALUES (21, 7, 1, 1);
INSERT INTO `worldcharacters` VALUES (16, 2, 2, 1);
INSERT INTO `worldcharacters` VALUES (18, 4, 1, 1);
INSERT INTO `worldcharacters` VALUES (19, 5, 1, 1);
INSERT INTO `worldcharacters` VALUES (17, 3, 1, 1);

-- ----------------------------
-- Table structure for worldservers
-- ----------------------------
DROP TABLE IF EXISTS `worldservers`;
CREATE TABLE `worldservers`  (
  `Id` smallint(6) NOT NULL,
  `Name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Type` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `MonoAccount` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `Host` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `Port` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = MyISAM CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of worldservers
-- ----------------------------
INSERT INTO `worldservers` VALUES (1, 'Jiva', 'SERVER_TYPE_CLASSICAL', '0', '127.0.0.1', 5555);

SET FOREIGN_KEY_CHECKS = 1;
